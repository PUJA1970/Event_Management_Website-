import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AdminComponent } from './admin/admin.component';
import { ContactComponent } from './contact/contact.component';
import { ParticipantLoginComponent } from './participant/participant-login/participant-login.component';
import { ParticipantLogoutComponent } from './participant/participant-logout/participant-logout.component';
import { ParticipantDashboardComponent } from './participant/participant-dashboard/participant-dashboard.component';
import { ParticipantRegisterComponent } from './participant/participant-register/participant-register.component';
import { ParticipantComponent } from './participant/participant.component';
import { HomeComponent } from './home/home.component';
import { OrganizerHomeComponent } from './organizer/organizer-home/organizer-home.component';
import { OrganizerLoginComponent } from './organizer/organizer-login/organizer-login.component';
import { OrganizerLogoutComponent } from './organizer/organizer-logout/organizer-logout.component';
import { OrganizerDashboardComponent } from './organizer/organizer-dashboard/organizer-dashboard.component';
import { OrganizerRegisterComponent } from './organizer/organizer-register/organizer-register.component';
import { OrganizerComponent } from './organizer/organizer.component';
import { EventListComponent } from './event/event-list/event-list.component';
import { AddEventComponent } from './event/add-event/add-event.component';
import { DeleteEventComponent } from './event/delete-event/delete-event.component';
import { UpdateEventComponent } from './event/update-event/update-event.component';
import { EventComponent } from './event/event.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SearchEventComponent } from './event/search-event/search-event.component';

const routes: Routes = [
  {path:"home", component:HomeComponent},
  {path:"about", component:AboutComponent},
  //{path:"services", component:ServicesComponent},
  //{path:"team", component:TeamComponent},
  {path:"contact", component:ContactComponent},

  {path: "", redirectTo: "dashboard", pathMatch: "full"},
  {path:"dashboard", component: DashboardComponent,
    children: [
    {path:"home", component:HomeComponent},
    {path:"about", component:AboutComponent},
    {path:"contact", component:ContactComponent},
    
    //{path:"organizer", component:OrganizerComponent},
   //children: [
      // {path:"organizer-login", component: OrganizerLoginComponent},
      //{path:"organizer-register", component: OrganizerRegisterComponent},
     //]
     // },
  ]
},


  
{path:"organizer", component: OrganizerComponent, 
children: [
  {path:"organizer-login", component: OrganizerLoginComponent},
  {path:"organizer-register", component: OrganizerRegisterComponent},
  {path:"organizer-logout", component: OrganizerLogoutComponent},
  {path:"organizer-dashboard", component: OrganizerDashboardComponent,

children:[
  // {path:"organizer-home", component: OrganizerHomeComponent},
    {path:"event", component: EventComponent, 
      children:[
      {path:"add-event", component:AddEventComponent},
      {path:"show-all-events", component:EventListComponent},
      {path:"update-event/:id", component: UpdateEventComponent},
      {path:"delete-event/:id", component: DeleteEventComponent},  
  ]
  },
]
},
]},



{path:"participant", component: ParticipantComponent, 
children: [
  {path:"participant-login", component: ParticipantLoginComponent},
  {path:"participant-register", component: ParticipantRegisterComponent},
  {path:"participant-logout", component: ParticipantLogoutComponent},
  {path:"participant-dashboard", component: ParticipantDashboardComponent,
  

  children: [
    {path: "event", component:EventComponent,
    children:[
    {path:"search-event", component:SearchEventComponent}
  ]},
]
},
]}
  
];  


/*
]
},

     
 
  
];  
*/


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
