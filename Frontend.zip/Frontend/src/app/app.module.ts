import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { FormsModule } from '@angular/forms';
import { AdminComponent } from './admin/admin.component';
import { AdminLoginComponent } from './admin/admin-login/admin-login.component';
import { OrganizerComponent } from './organizer/organizer.component';
import { OrganizerLoginComponent } from './organizer/organizer-login/organizer-login.component';
import { OrganizerHomeComponent } from './organizer/organizer-home/organizer-home.component';
import { OrganizerRegisterComponent } from './organizer/organizer-register/organizer-register.component';
import { EventComponent } from './event/event.component';
import { AddEventComponent } from './event/add-event/add-event.component';
import { DeleteEventComponent } from './event/delete-event/delete-event.component';
import { UpdateEventComponent } from './event/update-event/update-event.component';
import { ParticipantComponent } from './participant/participant.component';
import { ParticipantLoginComponent } from './participant/participant-login/participant-login.component';
import { AdminHomeComponent } from './admin/admin-home/admin-home.component';
import { OrganizerDashboardComponent } from './organizer/organizer-dashboard/organizer-dashboard.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { OrganizerLogoutComponent } from './organizer/organizer-logout/organizer-logout.component';
import { ParticipantRegisterComponent } from './participant/participant-register/participant-register.component';
import { ParticipantLogoutComponent } from './participant/participant-logout/participant-logout.component';
import { ParticipantDashboardComponent } from './participant/participant-dashboard/participant-dashboard.component';
import { EventListComponent } from './event/event-list/event-list.component';
import { OrganizerListComponent } from './organizer/organizer-list/organizer-list.component';
import { SearchEventComponent } from './event/search-event/search-event.component';





@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ContactComponent,
    AdminComponent,
    AdminLoginComponent,
    OrganizerComponent,
    OrganizerLoginComponent,
    OrganizerHomeComponent,
    OrganizerRegisterComponent,
    EventComponent,
    AddEventComponent,
    DeleteEventComponent,
    UpdateEventComponent,
    ParticipantComponent,
    ParticipantLoginComponent,
    AdminHomeComponent,
    OrganizerDashboardComponent,
    DashboardComponent,
    OrganizerLogoutComponent,
    ParticipantRegisterComponent,
    ParticipantLogoutComponent,
    ParticipantDashboardComponent,
    EventListComponent,
    OrganizerListComponent,
    SearchEventComponent
    
   

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
