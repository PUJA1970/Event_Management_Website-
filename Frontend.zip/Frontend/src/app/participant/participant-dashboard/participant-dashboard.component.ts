import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-participant-dashboard',
  templateUrl: './participant-dashboard.component.html',
  styleUrls: ['./participant-dashboard.component.css']
})
export class ParticipantDashboardComponent implements OnInit {
  loggedInUsername: string = "";
  constructor() { }

  ngOnInit() {
    this.loggedInUsername = window.sessionStorage.getItem("loggedin-username");
  }

}
