export class Participant {
    constructor(
        public participantId: number,
        public name: string,
        public userName: string,
        public email: string,
        public pswd: string,
        public gender: string,
        public dateOfBirth: Date,
        public contactNo: string,
        public address: string,
        public occupation: string,
        public registrationDate: Date
    ) { }
}
