import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Participant } from '../participant';
import { ParticipantService } from '../participant.service';

@Component({
  selector: 'app-participant-register',
  templateUrl: './participant-register.component.html',
  styleUrls: ['./participant-register.component.css']
})
export class ParticipantRegisterComponent implements OnInit {
  participant: Participant = new Participant(0, "", "", "", "" ,"", new Date(),"", "", "",new Date());
  message: string = "";

  getToday(): string {

    return new Date().toISOString().split('T')[0]

 }

  constructor(private service: ParticipantService, private router: Router) { }

  ngOnInit() {
  }

  onsubmit() {

    console.log(this.participant);
    this.service.participantRegister(this.participant).subscribe(data => {
      console.log(data instanceof Participant);
      console.log(data);
      if(data) {
  
        alert("Participant Registered successfully");
        this.router.navigateByUrl("/participant/participant-login");
      }
      else {
        alert("Username or ContactNo already registered:");
       
      }
    
  
    },error=>{
      alert(error.message);
    })
    }
  }




    /*
    console.log(this.participant);
    this.service.participantRegister(this.participant).subscribe(data => {
      console.log(data);
      this.participant = data;
      alert("Registered successfully");
      this.router.navigateByUrl("/participant/participant-login");
    
  
    },error =>{
      alert(error.message);
    });
    }
}
*/