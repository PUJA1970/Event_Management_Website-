import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Participant } from './participant';

@Injectable({
  providedIn: 'root'
})
export class ParticipantService {

  public participants : Participant[] = [];

  constructor(private _httpClient: HttpClient) { }

  participantLogin(participant: Participant): Observable<Participant> {
    let url: string = "http://localhost:9090/participant/login";
    return this._httpClient.post<Participant>(url, participant).pipe(map(response => response));
  }

  participantRegister(participant: Participant): Observable<Participant> {
    let url: string = "http://localhost:9090/participant/register";
    return this._httpClient.post<Participant>(url, participant).pipe(map(response => response));
  }
}
