 
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Participant } from '../participant';
import { ParticipantService } from '../participant.service';
@Component({
  selector: 'app-participant-login',
  templateUrl: './participant-login.component.html',
  styleUrls: ['./participant-login.component.css']
})
export class ParticipantLoginComponent implements OnInit {
  participant: Participant = new Participant(0, "", "", "", "" ,"",null, "", "", "",null);
  message: string = "";
  constructor(private service: ParticipantService, private router: Router) { }

  ngOnInit() {

  }
  onsubmit() {
    console.log(this.participant);
    this.service.participantLogin(this.participant).subscribe(data => {
      console.log(data);
      if(data) {
        alert("Participant Login Successfully");
       window.sessionStorage.setItem("loggedin-username",this.participant.userName);
       window.sessionStorage.setItem("loggedin-status","loggedin");
        this.router.navigateByUrl("participant/participant-dashboard");
      }
      else {
        alert("Invalid Username or password try to login again");
        this.router.navigateByUrl("participant/participant-login");
      }
  
    })

}
}


