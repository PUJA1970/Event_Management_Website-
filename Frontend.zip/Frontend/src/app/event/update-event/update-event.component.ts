import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Event } from '../event';
import { EventService } from '../event.service';

@Component({
  selector: 'app-update-event',
  templateUrl: './update-event.component.html',
  styleUrls: ['./update-event.component.css']
})
export class UpdateEventComponent implements OnInit {

  eventId: number = 0;
  event: Event = null;
  

  constructor(private activatedRoute: ActivatedRoute, private service: EventService, private router: Router) { }

  ngOnInit() {
    let evtId: number = 0;
    this.activatedRoute.params.subscribe(data => {
      this.eventId = data.id;

      this.service.getEvent(this.eventId).subscribe(response => {
        console.log(response);
        this.event = response;
      }, 
      error => {
        alert(error.message);
      })

    })
  }


  onupdate() {
    this.service.updateEvent(this.event).subscribe(data => {
      console.log(data);
      alert("Event updated successfully");
      this.router.navigateByUrl("organizer/organizer-dashboard/event/show-all-events");
    }, error => {
      console.log(error.message);
    })
  }

}
