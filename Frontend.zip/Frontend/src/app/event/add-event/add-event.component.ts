import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Organizer } from 'src/app/organizer/organizer';
import { OrganizerService } from 'src/app/organizer/organizer.service';
import { Event } from '../event';
import { EventService } from '../event.service';

@Component({
  selector: 'app-add-event',
  templateUrl: './add-event.component.html',
  styleUrls: ['./add-event.component.css']
})
export class AddEventComponent implements OnInit {
  event: Event = new Event(0, "", "","", "","",null,0,new Organizer(0, "", "", "", "", "", ""));
  message: string = "";

  organizers: Organizer[] = [];

  constructor(private service: EventService, private organizerService:OrganizerService ,private router: Router) { }


  ngOnInit() {
    this.organizerService.getAllOrganizers().subscribe(data => {
      this.organizers = data;
      console.log(this.organizers);
    }, error => {
      alert("Problem fetching events");  
    })
    
    
  }

  onsubmit() {
    console.log(this.event);

   
   /*let organizerName = window.sessionStorage.getItem("loggedin-username");
   console.log(organizerName);

    this.organizers.forEach(organizer => {
      if(organizer.name === organizerName) {
        console.log("inside if "+organizer.organizerId);
        this.event.organizer.organizerId = organizer.organizerId;
      }
    })
    */

  console.log("loggedin-userId="+window.sessionStorage.getItem("loggedin-userId"));
   this.event.organizer.organizerId= parseInt(window.sessionStorage.getItem("loggedin-userId"));


    this.service.addEvent(this.event).subscribe(data => {
      console.log(data);
      if(data) {
        alert("Event added successfully");
        this.event= new Event(0, "", "","", "","",null,0,new Organizer(0, "", "", "", "", "", ""));

        //this.router.navigateByUrl("/event/show-all-events");

      }
      else {
        alert("Problem adding event");
        //this.router.navigateByUrl("/event/show-all-events");
      }

    })
  }
}
