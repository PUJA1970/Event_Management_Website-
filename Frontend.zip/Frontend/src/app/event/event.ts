import { Organizer } from "../organizer/organizer";

export class Event {
    constructor(
        public eventId: number,
        public name: string,
        public address: string,
        public city: string,
        public pincode: string,
        public description: string,
        public date: Date,
        public price: number,
        public organizer: Organizer,
    ){}
}


