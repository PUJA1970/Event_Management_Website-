import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Event } from './event';

@Injectable({
  providedIn: 'root'
})
export class EventService {

  private events : Event [] = [];
  constructor(private _httpClient: HttpClient) { }

  getAllEvents(): Observable<Event[]> {
    let url: string = "http://localhost:9090/event/events";
    return this._httpClient.get<Event[]>(url).pipe(map(response => response));
  }

  addEvent(event: Event): Observable<Event> {
    console.log("organanizerId in service ="+event.organizer.organizerId)
    let url: string = "http://localhost:9090/event/organizers/"+event.organizer.organizerId+"/events";
    return this._httpClient.post<Event>(url, event).pipe(map(response => response));
  }

  getEvent(eventId: number): Observable<Event> {
    let url: string = "http://localhost:9090/event/events/"+eventId;
    return this._httpClient.get<Event>(url).pipe(map(response => response));
  }

  updateEvent(event: Event): Observable<Event> {
    let url: string = "http://localhost:9090/event/events/"+event.eventId;
    return this._httpClient.put<Event>(url, event).pipe(map(response => response));
  }

  deleteEvent(eventId: number): Observable<boolean> {
    let url: string = "http://localhost:9090/event/events/"+eventId;
    return this._httpClient.delete<boolean>(url).pipe(map(response => response));
  }

  searchEvent( city: string): Observable<Event[]>{
    let url: string = "http://localhost:9090/event/events/city/"+city;
    return this._httpClient.get<Event[]>(url).pipe(map(response => response));
  }
}

