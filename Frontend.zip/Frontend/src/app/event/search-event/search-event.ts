export class SearchEvent {
    constructor(public organizer: string, 
        public city: string){}

}