import { Component, OnInit } from '@angular/core';
import { Event } from '../event';
import { EventService } from '../event.service';
import { SearchEvent } from './search-event';

@Component({
  selector: 'app-search-event',
  templateUrl: './search-event.component.html',
  styleUrls: ['./search-event.component.css']
})
export class SearchEventComponent implements OnInit {

  searchEvent: SearchEvent = new SearchEvent("","");
  events: Event[] = [];
  message: string = "";

  constructor(private eventService: EventService) { }

  ngOnInit() {
   
  }
  onsubmitsearch(){
    this.eventService.searchEvent(this.searchEvent.city).subscribe(data =>{
      this.events = data;
      console.log(data);
      if(data.length == 0){
        this.message = "No events available for this city";
        alert("No events available for this city");
      }
      else{
        this.message = "Event are available for this city";
      }
    })
  }

}
