import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Organizer } from './organizer';

@Injectable({
  providedIn: 'root'
})
export class OrganizerService {

  private organizers: Organizer[] = [];

  constructor(private _httpClient: HttpClient) { }
  
  getAllOrganizers(): Observable<Organizer[]> {
    let url: string = "http://localhost:9090/organizer/organizers";

    return this._httpClient.get<Organizer[]>(url).pipe(map(response => response));
  }
  
  
  addOrganizer(organizer: Organizer): Observable<Organizer> {
    let url: string = "http://localhost:9090/api/categories/1/organizers";
    return this._httpClient.post<Organizer>(url, Organizer).pipe(map(response => response));
  }
  

  organizerLogin(organizer: Organizer): Observable<Organizer> {
    let url: string = "http://localhost:9090/organizer/login";
    return this._httpClient.post<Organizer>(url, organizer).pipe(map(response => response));
  }

  organizerRegister(organizer: Organizer): Observable<Organizer> {
    let url: string = "http://localhost:9090/organizer/register";
    return this._httpClient.post<Organizer>(url, organizer).pipe(map(response => response));
  }

  getOrganizer(organizerId: number): Observable<Organizer> {
    let url: string = "http://localhost:9090/organizers/"+organizerId;
    return this._httpClient.get<Organizer>(url).pipe(map(response => response));
  }

  updateOrganizer(organizer: Organizer): Observable<Organizer> {
    let url: string = "http://localhost:9090/organizers/"+organizer.organizerId;
    return this._httpClient.put<Organizer>(url, organizer).pipe(map(response => response));
  }

  deleteOrganizer(organizerId: number): Observable<boolean> {
    let url: string = "http://localhost:9090/organizer/"+organizerId;
    return this._httpClient.delete<boolean>(url).pipe(map(response => response));
  }
}

