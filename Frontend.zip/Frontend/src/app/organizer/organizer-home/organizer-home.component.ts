import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-organizer-home',
  templateUrl: './organizer-home.component.html',
  styleUrls: ['./organizer-home.component.css']
})
export class OrganizerHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
