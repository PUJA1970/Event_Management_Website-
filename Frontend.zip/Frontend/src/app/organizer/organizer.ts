export class Organizer {
    constructor(
        public organizerId: number,
        public name: string,
        public userName: string,
        public email: string,
        public pswd: string,
        public contactNo: string,
        public address: string,

    ){}
}
