import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-organizer-dashboard',
  templateUrl: './organizer-dashboard.component.html',
  styleUrls: ['./organizer-dashboard.component.css']
})
export class OrganizerDashboardComponent implements OnInit {
   
  loggedInUsername: string = "";
  constructor() { }

  ngOnInit() {

    this.loggedInUsername = window.sessionStorage.getItem("loggedin-username");
  }

}
