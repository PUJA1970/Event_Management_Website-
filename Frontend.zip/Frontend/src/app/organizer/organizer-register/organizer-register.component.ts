import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Organizer } from '../organizer';
import { OrganizerService } from '../organizer.service';

@Component({
  selector: 'app-organizer-register',
  templateUrl: './organizer-register.component.html',
  styleUrls: ['./organizer-register.component.css']
})
export class OrganizerRegisterComponent implements OnInit {
  organizer: Organizer = new Organizer(0, "", "", "", "", "","");
  message: string = "";

  constructor(private service: OrganizerService, private router: Router) { }


  ngOnInit() {
  }
  onsubmit() {
    console.log(this.organizer);
    this.service.organizerRegister(this.organizer).subscribe(data => {
      console.log(data instanceof Organizer);
      console.log(data);
      if(data) {
  
        alert("Organizer Registered successfully");
        this.router.navigateByUrl("/organizer/organizer-login");
      }
      else {
        alert("Username or ContactNo already registered:");
       
      }
    
  
    },error=>{
      alert(error.error.message);
    })
    }
  }
    /*   
    console.log(this.organizer);
    this.service.organizerRegister(this.organizer).subscribe(data => {
      console.log(data instanceof Organizer);
      if(data) {
        alert("Registered successfully");
        this.router.navigateByUrl("/organizer/organizer-login");
      }
      else {
        alert("Try to register again");
        this.router.navigateByUrl("/organizer/organizer-register");
      }
  
    },error =>{
      alert(error.message);
    })
    }
    
}
*/