import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Organizer } from '../organizer';
import { OrganizerService } from '../organizer.service';

@Component({
  selector: 'app-organizer-login',
  templateUrl: './organizer-login.component.html',
  styleUrls: ['./organizer-login.component.css']
})
export class OrganizerLoginComponent implements OnInit {
  organizer: Organizer = new Organizer(0, "", "", "", "", "","");
  message: string = "";

  constructor(private service: OrganizerService, private router: Router) { }

  ngOnInit() {
  }

  onsubmit() {
  console.log(this.organizer);
  this.service.organizerLogin(this.organizer).subscribe(data => {
    console.log(data);
    if(data) {
      alert("Organizer Login successfully");
      window.sessionStorage.setItem("loggedin-username",data.userName);
      window.sessionStorage.setItem("loggedin-userId",""+data.organizerId);
      window.sessionStorage.setItem("loggedin-status","loggedin");
      this.router.navigateByUrl("/organizer/organizer-dashboard");
    }
    else {
      alert("Invalid Username or password try to login again");
      this.router.navigateByUrl("/organizer/organizer-login");
    }

  })
  }
}
