import { Component, OnInit } from '@angular/core';
import { Organizer } from '../organizer';
import { OrganizerService } from '../organizer.service';
@Component({
  selector: 'app-organizer-list',
  templateUrl: './organizer-list.component.html',
  styleUrls: ['./organizer-list.component.css']
})
export class OrganizerListComponent implements OnInit {

  organizers: Organizer [] = [];

  constructor(private organizerService: OrganizerService) { }

  ngOnInit() {
    this.organizerService.getAllOrganizers().subscribe(data => {
      this.organizers = data;
      console.log(data);
    });
  }

}
