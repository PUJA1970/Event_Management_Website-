package demo.event.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import demo.event.exceptions.NullObjectException;
import demo.event.exceptions.ResourceNotEmptyException;
import demo.event.exceptions.ResourceNotFoundException;
import demo.event.exceptions.UserNameAlreadyExistsException;
import demo.event.exceptions.UsernameNotFoundException;
import demo.event.model.Organizer;
import demo.event.repository.OrganizerRepository;

@Service
public class OrganizerService {

	// Call method from Repo..
	@Autowired
	private OrganizerRepository organizerRepository;

	public Organizer registerOrganizer(@Valid @RequestBody Organizer newOrganizer) {
		Organizer organizer = null;
		/*List<Organizer> organizerList = organizerRepository.findAll();
		
		System.out.println("New organizer: " + newOrganizer.toString());
		for (Organizer o : organizerList) {
			System.out.println("Registered user: " + newOrganizer.toString());
			if (o.getUserName().equals(newOrganizer.getUserName())) {
				System.out.println("Organizer Already exists!");
				throw new UserNameAlreadyExistsException("Organizer Already exists!");
			}
		}
		*/
		Organizer o = organizerRepository.findByUserName(newOrganizer.getUserName());
		if(o!=null) {
			throw new UserNameAlreadyExistsException("Organizer Already exists!");
		}
		organizer = organizerRepository.save(newOrganizer);
		System.out.println(organizer)	;	
		return organizer;
	}

	public Organizer organizerLogin(@RequestBody Organizer organizer) {
		String userName=organizer.getUserName();
		String pswd = organizer.getPswd();
		Organizer organizerObj = null;
		if(userName!= null && pswd != null) {
			organizerObj = organizerRepository.findByUserNameAndPswd(userName, pswd);
			 System.out.println("login successfully");
		}
		return organizerObj;

	}

	//Organizer CRUD 
	
    
    public List<Organizer> getAllOrganizer(){
		List<Organizer> organizerList = new ArrayList<Organizer>();
		Iterable<Organizer> it= organizerRepository.findAll();
		
		it.forEach((organizer) ->{
			organizerList.add(organizer);
		});
		return organizerList;
	}
    
	
	public Organizer getOrganizerById(int id) {
		Optional<Organizer> opt = organizerRepository.findById(id);
		Organizer organizer = null;
		if(opt.isPresent())
		 {
			organizer = opt.get();
		}
		return organizer;
	}
	
	public Organizer addOrganizer(Organizer organizer) {
		if(organizer == null) {
			throw new NullObjectException("Organizer object is null");
		}
		return organizerRepository.save(organizer);

	}
	
	public Organizer updateOrganizer(Organizer organizer) {
		if(organizer == null) {
			throw new NullObjectException("Organizer not present");
		}
		Optional<Organizer> opt = organizerRepository.findById(organizer.getOrganizerId());
		Organizer organizerObj = null;
		if(opt.isPresent()) {
			organizerObj = organizerRepository.save(organizer);
		}
		else {
			throw new ResourceNotFoundException("No organizer with id: "+organizer.getOrganizerId()+" found");
		}
		return organizerObj;
	}
	
	public void delete(int organizerId) {
		Optional<Organizer> opt = organizerRepository.findById(organizerId);
		Organizer organizerObj = null;
		if(opt.isPresent()) {
			organizerObj = opt.get();
			if(organizerObj.getEvents().size() > 0) {
				throw new ResourceNotEmptyException("Organizer "+organizerId+" is contains some event hence cannot be deleted");
			}
			else {
				organizerRepository.delete(organizerObj);
			}
		}
		else {
			throw new ResourceNotFoundException("No organizer with id: "+organizerId+" found");
		}
	}
	
}
