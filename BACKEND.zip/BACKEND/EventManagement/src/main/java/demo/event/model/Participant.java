package demo.event.model;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
@Table(name = "participant", 
uniqueConstraints = { 
		@UniqueConstraint(columnNames = "participantusername"),
		@UniqueConstraint(columnNames = "participantemail"),
		@UniqueConstraint(columnNames = "participantcontact"),
})

public class Participant {

	@Id
	@Column(name = "participantid", scale = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name = "participant_participantid_seq")
	private int participantId;

	@Column(name = "participantname", length = 50)
	@NotEmpty(message = "Name is required")
	private String name;

	@Column(name = "participantusername", length = 50)
	@NotEmpty(message = "Username is required")
	private String userName;

	@Column(name = "participantemail", length = 50)
	@Email
	@NotEmpty(message = "Email is required")
	private String email;

	@Column(name = "participantpswd", length = 30)
	@Size(min = 8, max = 20)
	private String pswd;

	@Column(name = "participantgender", length = 30)
	@NotEmpty(message = "Gender is required")
	private String gender;

	@Column(name = "dateOfBirth")
	@Temporal(TemporalType.DATE)
	private Date dateOfBirth;
	
	
	@Column(name = "participantcontact")
	@NotEmpty(message = "Contact No is required")
	private String contactNo;

	@Column(name = "participantaddress")
	@NotEmpty(message = "Address is required")
	private String address;

	@Column(name = "participantoccupation")
	@NotEmpty(message = "Occupation is required")
	private String occupation;

	@Column(name = "dateOfRegistration")
	@Temporal(TemporalType.DATE)
	private Date registrationDate;

	public Participant() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Participant(int participantId, String name, String userName, String email, String pswd, String gender,Date dateOfBirth,
			String contactNo, String address, String occupation, Date registrationDate) {
		super();
		this.participantId = participantId;
		this.name = name;
		this.userName = userName;
		this.email = email;
		this.pswd = pswd;
		this.gender = gender;
		this.dateOfBirth = dateOfBirth;
		this.contactNo = contactNo;
		this.address = address;
		this.occupation = occupation;
		this.registrationDate = registrationDate;
	}

	public int getParticipantId() {
		return participantId;
	}

	public void setParticipantId(int participantId) {
		this.participantId = participantId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPswd() {
		return pswd;
	}

	public void setPswd(String pswd) {
		this.pswd = pswd;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			this.dateOfBirth = sdf.parse(dateOfBirth);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public Date getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(String registrationDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			this.registrationDate = sdf.parse(registrationDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public String toString() {
		return "Participant [participantId=" + participantId + ", name=" + name + ", userName=" + userName + ", email=" + email
				+ ", pswd=" + pswd + ", gender=" + gender + ", dateOfBirth=" + dateOfBirth + ", contactNo=" + contactNo
				+ ", address=" + address + ", occupation=" + occupation + ", registrationDate=" + registrationDate
				+ "]";
	}


}
