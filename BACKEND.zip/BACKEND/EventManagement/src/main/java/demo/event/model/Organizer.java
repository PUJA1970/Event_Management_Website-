package demo.event.model;

import java.util.List;
import java.util.Objects;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
@Table(name="organizer",
	uniqueConstraints = {
    @UniqueConstraint(columnNames = "organizerusername"),
    @UniqueConstraint(columnNames = "organizeremail"),
    @UniqueConstraint(columnNames = "organizercontact")
})

public class Organizer {
	
	@Id
	@Column(name="organizerid", scale=10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name="organizer_organizerid_seq")
	private int organizerId;
	
	@Column(name="companyname", length= 50)
	@NotEmpty(message = "Company name is required")
	private String name;
	
	@Column(name="organizerusername", length= 50,unique = true)
	@NotEmpty(message = "Username is required")
	private String userName;
	
	@Column(name="organizeremail", length= 50,unique = true)
	@Email
	@NotEmpty(message = "Email is required")
	private String email;
	
	@Column(name="organizerpswd", length= 30)
	@Size(min=8, max=20)
	private String pswd;
	
	
	@Column(name="organizercontact",unique = true)
	@NotEmpty(message = "Contact No is required")
	private String contactNo;
	
	@Column(name="organizeraddress")
	@NotEmpty(message = "Address is required")
	private String address;
	
	@OneToMany(mappedBy = "organizer")
	@JsonIgnoreProperties("organizer")
	private List<Event> events;

	public List<Event> getEvents() {
		return events;
	}

	public void setEvents(List<Event> events) {
		this.events = events;
	}

	public Organizer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Organizer(int organizerId, String name, String userName, String email, String pswd, String contactNo,
			String address) {
		super();
		this.organizerId = organizerId;
		this.name = name;
		this.userName = userName;
		this.email = email;
		this.pswd = pswd;
		this.contactNo = contactNo;
		this.address = address;
		
	}

	public int getOrganizerId() {
		return organizerId;
	}

	public void setOrganizerId(int organizerId) {
		this.organizerId = organizerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPswd() {
		return pswd;
	}

	public void setPswd(String pswd) {
		this.pswd = pswd;
	}


	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
	

	@Override
	public String toString() {
		return "Organizer [organizerId=" + organizerId + ", name=" + name + ", userName=" + userName + ", email=" + email
				+ ", pswd=" + pswd + ", contactNo=" + contactNo + ", address=" + address +  "]";
	}
	
	
}
