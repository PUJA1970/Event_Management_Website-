package demo.event.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import demo.event.exceptions.NullObjectException;
import demo.event.exceptions.ResourceNotFoundException;
import demo.event.exceptions.UsernameNotFoundException;
import demo.event.model.Organizer;
import demo.event.model.Event;
import demo.event.repository.OrganizerRepository;
import demo.event.repository.EventRepository;

@Service
public class EventService {

	@Autowired
	private EventRepository eventRepository;

	public List<Event> getAllEvents() {
		List<Event> events = new ArrayList<Event>();
		Iterable<Event> it = eventRepository.findAll();
		it.forEach(event -> {
			events.add(event);
		});
		return events; 
	}
	
	public Event getEventById(int id) {
		Optional<Event> opt = eventRepository.findById(id);
		Event evt = null;
		if(opt.isPresent()) {
			evt = opt.get();
		}
		return evt;
	}
	
	public Event addEvent(Event event) {
		
		if(event == null) {
			throw new NullObjectException("Event object is null in addEvent method");
		}
		System.out.println(event.getName());
		System.out.println("Event added successfully");
		System.out.println(event.getOrganizer());
		return eventRepository.save(event);
	}
	
	public Event updateEvent(Event event) {
		if(event == null) {
			throw new NullObjectException("Event object is null in addProperty method");
		}
		Optional<Event> opt = eventRepository.findById(event.getEventId());
		Event evt = null;
		if(opt.isPresent()) {
		    evt = eventRepository.save(event);
		}
		else {
			throw new ResourceNotFoundException("No event with id: "+event.getEventId()+" found");
		}
		return evt;
	}
	
	public void delete(int eventId) {
		
		Optional<Event> opt = eventRepository.findById(eventId);
		Event evt = null;
		if(opt.isPresent()) {
			evt = opt.get();
			eventRepository.delete(evt);
		}
		else {
			throw new ResourceNotFoundException("No event with id: "+eventId+" found");
		}
	}
	
	public List<Event> findAllByOrganizerOrganizerId(int eventId) {
		return eventRepository.findAllByOrganizerOrganizerId(eventId);
	}

	public List<Event> findAllByCity(String city){
		return eventRepository.findAllByCity(city) ;
	}
}
