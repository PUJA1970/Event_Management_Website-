package demo.event.exceptions;

public class UsernameNotFoundException extends RuntimeException{
	private String msg;

	
	public UsernameNotFoundException() {
		super("UsernameNotFoundException occured");
		this.msg = "UsernameNotFoundException occured";
	}
	
	public UsernameNotFoundException(String msg) {
		super(msg);
		this.msg = msg;
	}
	
}