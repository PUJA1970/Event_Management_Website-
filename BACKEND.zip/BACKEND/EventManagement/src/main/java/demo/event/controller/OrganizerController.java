package demo.event.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import demo.event.model.Organizer;
import demo.event.repository.OrganizerRepository;
import demo.event.service.OrganizerService;

@RestController
@CrossOrigin(value = "http://localhost:4200")
@RequestMapping("/organizer")
public class OrganizerController {

	// Call methods from service and use GetMapping, PostMapping

	@Autowired
	private OrganizerService service;

	@PostMapping("/register")
	public ResponseEntity<Organizer> registerOrganizer(@RequestBody Organizer organizer) {
		Organizer o = null;
		o= service.registerOrganizer(organizer);
		return new ResponseEntity<Organizer>(o, HttpStatus.OK);
	}

	@PostMapping("login")
	public Organizer loginUser(@RequestBody Organizer organizer) {
		return service.organizerLogin(organizer);
	}

	// CRUD

	@GetMapping("/organizers")
	public List<Organizer> getAllOrganizers() {
		return service.getAllOrganizer();
	}

	@PostMapping("/organizers")
	public Organizer addOrganizer(@RequestBody Organizer organizer) {
		return service.addOrganizer(organizer);
	}

	@GetMapping("/organizers/{id}")
	public Organizer getOrganizerById(@PathVariable("id") int id) {
		return service.getOrganizerById(id);
	}

	@PutMapping("/organizers/{id}")
	public Organizer updateOrganizer(@PathVariable("id") int organizerId, @RequestBody Organizer organizer) {
		organizer.setOrganizerId(organizerId);
		return service.updateOrganizer(organizer);
	}

	@DeleteMapping("/organizers/{id}")
	public void delete(@PathVariable("id") int organizerId) {
		service.delete(organizerId);
	}
}
