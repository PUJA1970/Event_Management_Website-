package demo.event.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import demo.event.model.Organizer;
import demo.event.model.Event;
import demo.event.service.EventService;

@RestController
@CrossOrigin(value = "http://localhost:4200")
@RequestMapping("/event")
public class EventController {

	@Autowired
	private EventService service;

	@GetMapping("/events")
	public List<Event> getAllEvents() {
		return service.getAllEvents();
	}

	@GetMapping("/organizers/{organizerId}/events")
	public List<Event> findAllByOrganizerOrganizerId(@PathVariable("organizerId")int organizerId) {
		return service.findAllByOrganizerOrganizerId(organizerId);
	}

	@PostMapping("/organizers/{organizerId}/events")
	public Event addEvent(@PathVariable("organizerId") int organizerId, @RequestBody Event p) {
		p.setOrganizer(new Organizer(organizerId,"","", "", "", "", ""));
		return service.addEvent(p);
	}

	@GetMapping("/events/{id}")
	public Event getEventById(@PathVariable("id")int id) { 
		return service.getEventById(id);	
	}

	@PutMapping("/events/{id}")
	public Event updateEvent(@PathVariable("id") int eventId, @RequestBody Event event) { 
		event.setEventId(eventId);
		return service.updateEvent(event);	
	}

	@DeleteMapping("/events/{id}")
	public void delete(@PathVariable("id")int eventId) { 
		service.delete(eventId);
	}

	@GetMapping("events/city/{city}")
	public List<Event> findAllByCity( @PathVariable("city") String city){
	return service.findAllByCity(city);
	}

}
