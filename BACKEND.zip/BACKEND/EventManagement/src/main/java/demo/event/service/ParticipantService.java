package demo.event.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import demo.event.exceptions.UserNameAlreadyExistsException;
import demo.event.model.Participant;
import demo.event.repository.ParticipantRepository;
import demo.event.repository.ParticipantRepository;

@Service
public class ParticipantService {

	
	@Autowired
	private ParticipantRepository participantRepository;

	public Participant registerParticipant(@Valid @RequestBody Participant newParticipant) {
		Participant participant = null;
		List<Participant> participantList = participantRepository.findAll();
		
		System.out.println("New participant: " + newParticipant.toString());
		for (Participant o : participantList) {
			System.out.println("Registered participant: " + newParticipant.toString());
			if (o.getUserName().equals(newParticipant.getUserName())) {
				System.out.println("Participant Already exists!");
				throw new UserNameAlreadyExistsException("Participant Already exists!");
			}
		}
		participant = participantRepository.save(newParticipant);
		return participant;
	}

	public Participant participantLogin(@RequestBody Participant participant) {
		String userName=participant.getUserName();
		String pswd = participant.getPswd();
		Participant participantObj = null;
		if(userName!= null && pswd != null) {
			participantObj = participantRepository.findByUserNameAndPswd(userName, pswd);
			 System.out.println("login successfully");
			 
		}
		return participantObj;

	}
}
