package demo.event.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import demo.event.model.Organizer;

@Repository
public interface OrganizerRepository extends JpaRepository<Organizer, Integer> {
 
  
	Organizer findByUserNameAndPswd(String userName, String pswd);
	Organizer findByUserName(String userName);
	Organizer findByEmail(String email);
	Organizer findByContactNo(String contactNo);
	

}