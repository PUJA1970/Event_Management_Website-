package demo.event.exceptions;

public class UserNameAlreadyExistsException extends RuntimeException{

private String msg;

	
	public UserNameAlreadyExistsException() {
		super("UserNameAlreadyExistsException occured");
		this.msg = "UserNameAlreadyExistsException occured";
	}
	
	public UserNameAlreadyExistsException(String msg) {
		super(msg);
		this.msg = msg;
	}
}
