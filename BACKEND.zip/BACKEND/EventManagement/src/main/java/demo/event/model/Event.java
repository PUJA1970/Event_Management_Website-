package demo.event.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
@Table(name = "event")
public class Event {

	@Id
	@Column(name = "evtid", scale = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name = "event_evtid_seq")
	private int eventId;

	@Column(name = "eventname", length = 50)
	@NotEmpty(message = "Name is required")
	private String name;

	@Column(name = "eventaddress", length = 100)
	@NotEmpty(message = "Address is required")
	private String address;
	
	@Column(name = "eventcity", length = 100)
	@NotEmpty(message = "City is required")
	private String city;

	@Column(name = "pincode", length = 100)
	@NotNull(message = "Pincode is required")
	@Size(max=6)
	private String pincode;
	
	@Column(name = "eventdescription")
	private String description;
	
	@Column(name = "eventdate")
	@Temporal(TemporalType.DATE)
	private Date date;

	@Column(name = "eventprice")
	@NotNull(message = "Price is required")
	private Integer price;
	
	@ManyToOne//(cascade = CascadeType.MERGE)
	@JoinColumn(name = "organizerid")
	@JsonIgnoreProperties("events")
	private Organizer organizer;

	public Event(int eventId, String name, String address, String city,String pincode, String description,Date date,
			Integer price, Organizer organizer) {
		super();
		this.eventId = eventId;
		this.name = name;
		this.address = address;
		this.city = city;
		this.pincode = pincode;
		this.description = description;
		this.date = date;
		this.price = price;
		this.organizer = organizer;
	}

	public Event() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public Date getDate() {
		return date;
	}

	public void setDate(String date) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			this.date = sdf.parse(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Organizer getOrganizer() {
		return organizer;
	}

	public void setOrganizer(Organizer organizer) {
		this.organizer = organizer;
	}

	@Override
	public String toString() {
		return "Event [eventId=" + eventId + ", name=" + name + ", address=" + address + ", city=" + city + ", pincode="
				+ pincode + ", description=" + description + ", date=" + date + ", price=" + price + ", organizer="
				+ organizer + "]";
	}

	
}
