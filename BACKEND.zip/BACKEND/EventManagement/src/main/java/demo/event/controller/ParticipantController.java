package demo.event.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import demo.event.model.Participant;
import demo.event.model.Organizer;
import demo.event.service.ParticipantService;
import demo.event.service.OrganizerService;

@RestController
@CrossOrigin(value = "http://localhost:4200")
@RequestMapping("/participant")
public class ParticipantController {
	
	@Autowired
	private ParticipantService service;

	@PostMapping("/register")
	public Participant registerParticipant(@RequestBody Participant participant) {
		Participant partObj = null;
		partObj= service.registerParticipant(participant);
		return partObj;
	}

	@PostMapping("login")
	public Participant loginParticipant(@RequestBody Participant participant) {
		return service.participantLogin(participant);
	}

}
