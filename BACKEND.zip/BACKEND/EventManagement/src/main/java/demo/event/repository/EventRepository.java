package demo.event.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import demo.event.model.Event;
import demo.event.model.Organizer;

@Repository
public interface EventRepository extends JpaRepository<Event, Integer>{
	
	public List<Event> findAllByOrganizerOrganizerId(int organizerId);
	
	public List<Event> findAllByCity(String city);
}
